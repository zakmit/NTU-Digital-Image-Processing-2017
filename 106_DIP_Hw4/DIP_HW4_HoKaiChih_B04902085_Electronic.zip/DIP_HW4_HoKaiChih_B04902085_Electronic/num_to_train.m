function outputArg1 = num_to_train(inputArg1)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
switch inputArg1
    case 1
        outputArg1 = "A";
    case 2
        outputArg1 = "C";
    case 3
        outputArg1 = "G";
    case 4
        outputArg1 = "H";
    case 5
        outputArg1 = "J";
    case 6
        outputArg1 = "K";
    case 7
        outputArg1 = "L";
    case 8
        outputArg1 = "M";
    case 9
        outputArg1 = "N";
    case 10
        outputArg1 = "B";
    case 11
        outputArg1 = "D";
    case 12
        outputArg1 = "E";
    case 13
        outputArg1 = "F";
    case 14
        outputArg1 = "I";
    case 15
        outputArg1 = "b";
    case 16
        outputArg1 = "O";
    case 17
        outputArg1 = "P";
    case 18
        outputArg1 = "Q";
    case 19
        outputArg1 = "R";
    case 20
        outputArg1 = "S";
    case 21
        outputArg1 = "T";
    case 22
        outputArg1 = "U";
    case 23
        outputArg1 = "V";
    case 24
        outputArg1 = "W";
    case 25
        outputArg1 = "X";
    case 26
        outputArg1 = "Y";
    case 27
        outputArg1 = "Z";
    case 28
        outputArg1 = "a";
    case 29
        outputArg1 = "d";
    case 30
        outputArg1 = "f";
    case 31
        outputArg1 = "h";
    case 32
        outputArg1 = "k";
    case 33
        outputArg1 = "l";
    case 34
        outputArg1 = "c";
    case 35
        outputArg1 = "e";
    case 36
        outputArg1 = "g";
    case 37
        outputArg1 = "i";
    case 38
        outputArg1 = "j";
    case 39
        outputArg1 = "m";
    case 40
        outputArg1 = "n";
    case 41
        outputArg1 = "o";
    case 42
        outputArg1 = "p";
    case 43
        outputArg1 = "0";
    case 44
        outputArg1 = "1";
    case 45
        outputArg1 = "2";
    case 46
        outputArg1 = "3";
    case 47
        outputArg1 = "t";
    case 48
        outputArg1 = "q";
    case 49
        outputArg1 = "r";
    case 50
        outputArg1 = "s";
    case 51
        outputArg1 = "u";
    case 52
        outputArg1 = "v";
    case 53
        outputArg1 = "w";
    case 54
        outputArg1 = "x";
    case 55
        outputArg1 = "y";
    case 56
        outputArg1 = "z";
    case 57
        outputArg1 = "4";
    case 58
        outputArg1 = "5";
    case 59
        outputArg1 = "6";
    case 60
        outputArg1 = "7";
    case 61
        outputArg1 = "8";
    case 62
        outputArg1 = "9";
    case 63
        outputArg1 = "!";
    case 64
        outputArg1 = "#";
    case 65
        outputArg1 = "$";
    case 66
        outputArg1 = "%";
    case 67
        outputArg1 = "^";
    case 68
        outputArg1 = "&";
    case 69
        outputArg1 = "@";
    case 70
        outputArg1 = "*";
end

