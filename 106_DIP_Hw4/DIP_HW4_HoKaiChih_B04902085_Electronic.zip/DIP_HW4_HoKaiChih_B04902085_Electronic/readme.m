% DIP Homework Assignment #4
% May. 29, 2018
% Name: Ho Kai Chih
% ID #: B04902085
% email: b04902085@ntu.edu.tw
%###############################################################################%
% Problem 1: OCR
% Implementation 1: OCR
% M-file name: P1.m
% Usage: P1
% Output image: I1.raw, I2.raw, Train.raw, [1~70].png, i1[1~5].png,
% i2[1~6].png
% Parameters: none
% Other parameters here
%###############################################################################%
disp('Please put input files into "raw" folder'); %display some useful information
disp('Running "P1"...'); %display some useful information
P1; % invoke your M-file properly!
disp('Done, "P1", output images are "I1.raw " for Sample1 after preprocess, "I2.raw " for Sample2 after preprocess, "Train.raw " for Training Set after preprocess');
disp('[1~70].png are characters according to their number(having been disabled by comment), i1[1~5].png and i2[1~5].png are i1 and i2 chacter according to its order(output order)')
%###############################################################################%
